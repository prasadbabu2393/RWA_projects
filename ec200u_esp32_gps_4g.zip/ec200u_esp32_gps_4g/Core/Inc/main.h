/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   STM32 GPS Parser for EC200U to ESP32 communication
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32l4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
/* USER CODE BEGIN Private defines */

// GPIO Pin definitions
#define LED_STATUS_Pin GPIO_PIN_0          // PA0 - Status LED
#define LED_STATUS_GPIO_Port GPIOA
#define EC200U_PWRKEY_Pin GPIO_PIN_5       // PA5 - EC200U Power Key
#define EC200U_PWRKEY_GPIO_Port GPIOA

// UART Pin definitions
#define ESP32_TX_Pin GPIO_PIN_9            // PA9 - To ESP32 RX
#define ESP32_RX_Pin GPIO_PIN_10           // PA10 - From ESP32 TX
#define EC200U_TX_Pin GPIO_PIN_2           // PA2 - To EC200U RX
#define EC200U_RX_Pin GPIO_PIN_3           // PA3 - From EC200U TX

// UART handle definitions
extern UART_HandleTypeDef huart1;         // ESP32 communication
extern UART_HandleTypeDef huart2;         // EC200U communication

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
