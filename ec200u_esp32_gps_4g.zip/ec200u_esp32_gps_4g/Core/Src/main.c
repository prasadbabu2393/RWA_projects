/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : STM32 GPS PROGRESSIVE WITH SMS (4-DECIMAL PRECISION)
  * @author         : Enhanced GPS + SMS with precise coordinates
  ******************************************************************************
  * Based on working GPS code, now with enhanced 4-decimal coordinate precision
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart1;  // ESP32 UART
UART_HandleTypeDef huart2;  // EC200U UART

/* USER CODE BEGIN PV */

// Communication buffers
char ec200u_rx_buffer[1024];
char ec200u_tx_buffer[256];
char esp32_tx_buffer[512];
volatile uint16_t ec200u_rx_index = 0;

// GPS data structure (enhanced with 4-decimal precision)
typedef struct {
    uint8_t module_ready;
    uint8_t gnss_started;
    uint8_t has_valid_location;
    uint8_t sms_ready;
    uint8_t sms_enabled;

    // Parsed GPS data
    char latitude[20];
    char longitude[20];
    char timestamp[20];
    char altitude[16];
    char satellites[8];
    uint8_t fix_type;

    // High-precision decimal coordinates for SMS (4 decimal places)
    float decimal_lat;
    float decimal_lon;

    // Status counters
    uint32_t last_update;
    uint32_t location_updates;
    uint32_t gps_attempts;
    uint32_t communication_errors;
    uint32_t sms_sent_count;
    uint32_t sms_failed_count;
} gps_data_t;

gps_data_t gps_data = {0};

// SMS Configuration
#define SMS_PHONE_NUMBER "+918903454590"  // TARGET PHONE NUMBER
//#define SMS_INTERVAL_MS 28800000              // 8 hours for production
#define SMS_INTERVAL_MS 30000              // 30 seconds for testing

// Timing and control variables
uint32_t heartbeat_counter = 0;
uint32_t last_gps_attempt = 0;
uint32_t last_status_update = 0;
uint32_t last_sms_sent = 0;
uint8_t initialization_step = 0;
uint8_t max_init_attempts = 3;
uint8_t current_init_attempt = 0;

// Function prototypes
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART2_UART_Init(void);

// Core functions
void ESP32_Printf(const char* format, ...);
void Status_LED_Toggle(void);
void Status_LED_Set(uint8_t state);
void EC200U_ClearRXBuffer(void);

// GPS functions (with enhanced precision)
uint8_t EC200U_SendCommand_Safe(const char* command, const char* expected_response, uint32_t timeout);
uint8_t EC200U_BasicTest(void);
uint8_t EC200U_Initialize_Progressive(void);
uint8_t EC200U_StartGNSS_Safe(void);
uint8_t EC200U_GetLocation_Safe(void);
void Handle_EC200U_Error(const char* error_msg);
float ConvertNMEAToDecimal(const char* nmea_coord);
void ConvertNMEAToString_HighPrecision(const char* nmea_coord, char* output_str, size_t output_size);  // ENHANCED: 4-decimal precision

// SMS functions
uint8_t EC200U_InitializeSMS(void);
uint8_t EC200U_SendSMS(const char* phone_number, const char* message);
uint8_t EC200U_SimpleSMSTest(void);
void Create_GPS_SMS_Message_HighPrecision(char* message_buffer, size_t buffer_size);  // ENHANCED: 4-decimal precision
void Handle_SMS_Operations(void);

/* USER CODE END PV */

int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();

  /* USER CODE BEGIN 2 */

  // Startup indication
  Status_LED_Set(1);
  HAL_Delay(1000);
  Status_LED_Set(0);
  HAL_Delay(2000);

  ESP32_Printf("=== STM32 GPS + SMS TRACKER V2.0 (4-DECIMAL PRECISION) ===\n");
  ESP32_Printf("SYSTEM:STM32_BOOTED_SUCCESSFULLY\n");
  ESP32_Printf("STATUS:UART_COMMUNICATION_VERIFIED\n");
  ESP32_Printf("SMS:TARGET_PHONE_%s\n", SMS_PHONE_NUMBER);
  ESP32_Printf("GPS:ENHANCED_4_DECIMAL_PRECISION_ENABLED\n");
  ESP32_Printf("DEBUG:STARTING_PROGRESSIVE_GPS_SMS_INITIALIZATION\n");

  // Enable SMS by default
  gps_data.sms_enabled = 1;

  /* USER CODE END 2 */

  /* Infinite loop */
  while (1)
  {
    /* USER CODE BEGIN 3 */

    uint32_t current_time = HAL_GetTick();
    heartbeat_counter++;

    // Heartbeat every 3 seconds
    if (current_time - last_status_update >= 3000) {
        ESP32_Printf("=== HEARTBEAT #%lu (Step %d) ===\n", heartbeat_counter, initialization_step);
        ESP32_Printf("SYSTEM:ALIVE_TICK_%lu\n", current_time);
        ESP32_Printf("STATUS:MODULE_%d,GNSS_%d,GPS_LOC_%d,SMS_%d\n",
                     gps_data.module_ready, gps_data.gnss_started,
                     gps_data.has_valid_location, gps_data.sms_ready);
        ESP32_Printf("STATS:GPS_ATTEMPTS_%lu,UPDATES_%lu,SMS_SENT_%lu,ERRORS_%lu\n",
                     gps_data.gps_attempts, gps_data.location_updates,
                     gps_data.sms_sent_count, gps_data.communication_errors);

        last_status_update = current_time;
        Status_LED_Toggle();
    }

    // Progressive initialization (only try a few times to avoid infinite loops)
    if (initialization_step == 0 && current_init_attempt < max_init_attempts) {
        ESP32_Printf("DEBUG:INITIALIZATION_STEP_0_BASIC_TEST_ATTEMPT_%d\n", current_init_attempt + 1);

        if (EC200U_BasicTest()) {
            ESP32_Printf("SUCCESS:BASIC_EC200U_COMMUNICATION_WORKING\n");
            initialization_step = 1;
            current_init_attempt = 0;  // Reset for next step
        } else {
            current_init_attempt++;
            ESP32_Printf("WARNING:BASIC_TEST_FAILED_ATTEMPT_%d\n", current_init_attempt);

            if (current_init_attempt >= max_init_attempts) {
                ESP32_Printf("ERROR:BASIC_TEST_FAILED_MAX_ATTEMPTS_REACHED\n");
                ESP32_Printf("SYSTEM:RUNNING_WITHOUT_GPS_MODULE\n");
                initialization_step = 99;  // Skip GPS functionality
            }
        }
        HAL_Delay(2000);  // Wait between attempts
    }

    else if (initialization_step == 1 && current_init_attempt < max_init_attempts) {
        ESP32_Printf("DEBUG:INITIALIZATION_STEP_1_MODULE_SETUP_ATTEMPT_%d\n", current_init_attempt + 1);

        if (EC200U_Initialize_Progressive()) {
            ESP32_Printf("SUCCESS:EC200U_MODULE_INITIALIZED\n");
            gps_data.module_ready = 1;
            initialization_step = 2;
            current_init_attempt = 0;
        } else {
            current_init_attempt++;
            ESP32_Printf("WARNING:MODULE_INIT_FAILED_ATTEMPT_%d\n", current_init_attempt);

            if (current_init_attempt >= max_init_attempts) {
                ESP32_Printf("ERROR:MODULE_INIT_FAILED_MAX_ATTEMPTS\n");
                initialization_step = 99;
            }
        }
        HAL_Delay(3000);
    }

    else if (initialization_step == 2 && current_init_attempt < max_init_attempts) {
        ESP32_Printf("DEBUG:INITIALIZATION_STEP_2_GNSS_START_ATTEMPT_%d\n", current_init_attempt + 1);

        if (EC200U_StartGNSS_Safe()) {
            ESP32_Printf("SUCCESS:GNSS_STARTED_SUCCESSFULLY\n");
            gps_data.gnss_started = 1;
            initialization_step = 3;  // Move to SMS test
            current_init_attempt = 0;
        } else {
            current_init_attempt++;
            ESP32_Printf("WARNING:GNSS_START_FAILED_ATTEMPT_%d\n", current_init_attempt);

            if (current_init_attempt >= max_init_attempts) {
                ESP32_Printf("ERROR:GNSS_START_FAILED_MAX_ATTEMPTS\n");
                initialization_step = 99;
            }
        }
        HAL_Delay(3000);
    }

    // SMS TEST (Step 3)
    else if (initialization_step == 3) {
        ESP32_Printf("=== STEP_3_IMMEDIATE_SMS_TEST ===\n");

        ESP32_Printf("SMS_TEST:TRYING_ULTRA_SIMPLE_SMS_APPROACH\n");

        // Try ultra-simple SMS test
        if (EC200U_SimpleSMSTest()) {
            ESP32_Printf("SUCCESS:SIMPLE_SMS_WORKED_SMS_READY\n");
            gps_data.sms_ready = 1;
            gps_data.sms_enabled = 1;
            gps_data.sms_sent_count++;

            // Flash LED 20 times for SMS success
            for (int i = 0; i < 20; i++) {
                Status_LED_Set(1);
                HAL_Delay(100);
                Status_LED_Set(0);
                HAL_Delay(100);
            }
        } else {
            ESP32_Printf("ERROR:SIMPLE_SMS_FAILED_TRYING_FULL_INIT\n");

            // Fallback to full SMS initialization
            if (EC200U_InitializeSMS()) {
                ESP32_Printf("SUCCESS:FULL_SMS_INIT_WORKED\n");
                gps_data.sms_ready = 1;
                gps_data.sms_enabled = 1;

                // Try sending SMS with full init
                char hello_message[] = "Hello from STM32 GPS Tracker V2.0! 4-decimal precision enabled.";
                if (EC200U_SendSMS(SMS_PHONE_NUMBER, hello_message)) {
                    ESP32_Printf("SUCCESS:FULL_INIT_SMS_SENT\n");
                    gps_data.sms_sent_count++;
                } else {
                    ESP32_Printf("ERROR:FULL_INIT_SMS_ALSO_FAILED\n");
                }
            } else {
                ESP32_Printf("ERROR:BOTH_SMS_METHODS_FAILED\n");
                gps_data.sms_enabled = 0;
            }
        }

        initialization_step = 4;  // Move to operational mode
        last_sms_sent = current_time;
        HAL_Delay(3000);
    }

    else if (initialization_step == 3 && !gps_data.sms_enabled) {
        ESP32_Printf("DEBUG:SMS_DISABLED_MOVING_TO_OPERATIONAL_MODE\n");
        initialization_step = 4;
    }

    else if (initialization_step == 4) {
        // Normal GPS + SMS operation
        if (current_time - last_gps_attempt >= 5000) {  // Try GPS every 5 seconds
            ESP32_Printf("DEBUG:ATTEMPTING_GPS_LOCATION_CHECK\n");

            if (EC200U_GetLocation_Safe()) {
                gps_data.location_updates++;
                ESP32_Printf("SUCCESS:GPS_LOCATION_UPDATED_COUNT_%lu\n", gps_data.location_updates);

                // Send GPS data to ESP32 (with high precision display)
                ESP32_Printf("GPS_LAT=%s\n", gps_data.latitude);
                ESP32_Printf("GPS_LON=%s\n", gps_data.longitude);
                ESP32_Printf("GPS_ALT=%s\n", gps_data.altitude);
                ESP32_Printf("GPS_SATS=%s\n", gps_data.satellites);
                ESP32_Printf("GPS_FIX=%d\n", gps_data.fix_type);
                ESP32_Printf("GPS_DECIMAL_LAT=%.6f\n", gps_data.decimal_lat);
                ESP32_Printf("GPS_DECIMAL_LON=%.6f\n", gps_data.decimal_lon);

                // Flash LED twice for GPS success
                for (int i = 0; i < 2; i++) {
                    Status_LED_Set(1);
                    HAL_Delay(50);
                    Status_LED_Set(0);
                    HAL_Delay(50);
                }
            } else {
                ESP32_Printf("DEBUG:GPS_LOCATION_NOT_AVAILABLE_YET\n");
            }

            last_gps_attempt = current_time;
        }

        // SMS operations (if enabled and working)
        if (gps_data.sms_enabled && gps_data.sms_ready && gps_data.has_valid_location) {
            // Convert coordinates to high-precision strings and show conversion
            char lat_str[20];
            char lon_str[20];
            ConvertNMEAToString_HighPrecision(gps_data.latitude, lat_str, sizeof(lat_str));
            ConvertNMEAToString_HighPrecision(gps_data.longitude, lon_str, sizeof(lon_str));

            ESP32_Printf("GPS_FOR_SMS_4DECIMAL:LAT=%s(%s),LON=%s(%s),ALT=%s,SATS=%s\n",
                         gps_data.latitude, lat_str,
                         gps_data.longitude, lon_str,
                         gps_data.altitude, gps_data.satellites);

            Handle_SMS_Operations();
        }
    }

    else if (initialization_step == 99) {
        // GPS failed, running in basic mode
        ESP32_Printf("SYSTEM:RUNNING_IN_BASIC_MODE_NO_GPS\n");
        HAL_Delay(10000);  // Long delay since no GPS functionality
    }

    HAL_Delay(100);  // Main loop delay

  }
  /* USER CODE END 3 */
}

/* USER CODE BEGIN 4 */

/**
  * @brief  Convert NMEA to decimal string with 4-decimal precision (ENHANCED VERSION)
  */
void ConvertNMEAToString_HighPrecision(const char* nmea_coord, char* output_str, size_t output_size)
{
    if (strlen(nmea_coord) < 8) {
        strcpy(output_str, "ERR");
        return;
    }

    // Extract degrees and minutes manually
    int degrees = 0;
    int minutes_int = 0;
    int minutes_frac = 0;

    ESP32_Printf("DEBUG_PRECISION:PROCESSING_NMEA=%s\n", nmea_coord);

    if (nmea_coord[0] == '0') {
        // Longitude format: 07729.7888E
        // Degrees: 77 (chars 1,2)
        degrees = (nmea_coord[1] - '0') * 10 + (nmea_coord[2] - '0');
        // Minutes: 29.7888 (chars 3,4 + decimal part)
        minutes_int = (nmea_coord[3] - '0') * 10 + (nmea_coord[4] - '0');

        // Get 4 decimal digits of minutes for high precision
        if (strlen(nmea_coord) > 6) {
            minutes_frac = (nmea_coord[6] - '0') * 1000;  // First decimal digit * 1000
            if (strlen(nmea_coord) > 7) {
                minutes_frac += (nmea_coord[7] - '0') * 100;  // Second decimal digit * 100
            }
            if (strlen(nmea_coord) > 8) {
                minutes_frac += (nmea_coord[8] - '0') * 10;   // Third decimal digit * 10
            }
            if (strlen(nmea_coord) > 9) {
                minutes_frac += (nmea_coord[9] - '0');        // Fourth decimal digit * 1
            }
        }
    } else {
        // Latitude format: 1300.1282N
        // Degrees: 13 (chars 0,1)
        degrees = (nmea_coord[0] - '0') * 10 + (nmea_coord[1] - '0');
        // Minutes: 00.1282 (chars 2,3 + decimal part)
        minutes_int = (nmea_coord[2] - '0') * 10 + (nmea_coord[3] - '0');

        // Get 4 decimal digits of minutes for high precision
        if (strlen(nmea_coord) > 5) {
            minutes_frac = (nmea_coord[5] - '0') * 1000;  // First decimal digit * 1000
            if (strlen(nmea_coord) > 6) {
                minutes_frac += (nmea_coord[6] - '0') * 100;  // Second decimal digit * 100
            }
            if (strlen(nmea_coord) > 7) {
                minutes_frac += (nmea_coord[7] - '0') * 10;   // Third decimal digit * 10
            }
            if (strlen(nmea_coord) > 8) {
                minutes_frac += (nmea_coord[8] - '0');        // Fourth decimal digit * 1
            }
        }
    }

    // Convert minutes to decimal degrees with 4-decimal precision
    // Total minutes = minutes_int + (minutes_frac/10000)
    // Decimal degrees = minutes / 60
    long total_minutes_x10000 = (long)minutes_int * 10000 + minutes_frac;
    long decimal_part = total_minutes_x10000 / 60;  // This gives us the decimal part * 10000

    ESP32_Printf("DEBUG_PRECISION:DEG=%d,MIN_INT=%d,MIN_FRAC=%d,TOTAL_MIN_x10000=%ld,DECIMAL_PART=%ld\n",
                 degrees, minutes_int, minutes_frac, total_minutes_x10000, decimal_part);

    // Format as XX.XXXX (4 decimal places)
    snprintf(output_str, output_size, "%d.%04ld", degrees, decimal_part);

    ESP32_Printf("DEBUG_PRECISION:FINAL_RESULT=%s\n", output_str);
}

/**
  * @brief  Create high-precision GPS message for SMS (WITH 4-DECIMAL PRECISION)
  */
void Create_GPS_SMS_Message_HighPrecision(char* message_buffer, size_t buffer_size)
{
    // Convert coordinates with 4-decimal precision
    char lat_str[20];
    char lon_str[20];

    ConvertNMEAToString_HighPrecision(gps_data.latitude, lat_str, sizeof(lat_str));
    ConvertNMEAToString_HighPrecision(gps_data.longitude, lon_str, sizeof(lon_str));

    ESP32_Printf("SMS_PRECISION:CREATING_4DECIMAL_MESSAGE_LAT=%s,LON=%s\n", lat_str, lon_str);

    // Create SMS message with 4-decimal coordinates
    snprintf(message_buffer, buffer_size,
             "GPS : %s,%s Alt:%sm Sats:%s Time:%s Maps: https://maps.google.com/?q=%s,%s",
             lat_str, lon_str,
             gps_data.altitude, gps_data.satellites, gps_data.timestamp,
             lat_str, lon_str);

    ESP32_Printf("SMS_PRECISION:MESSAGE_LENGTH=%d\n", strlen(message_buffer));
}

/**
  * @brief  Ultra-simple SMS test
  */
uint8_t EC200U_SimpleSMSTest(void)
{
    ESP32_Printf("=== SIMPLE_SMS_TEST_START ===\n");

    // Step 1: Basic AT test
    ESP32_Printf("SMS_SIMPLE:AT_TEST\n");
    if (!EC200U_SendCommand_Safe("AT", "OK", 2000)) {
        ESP32_Printf("ERROR:AT_FAILED\n");
        return 0;
    }

    // Step 2: Set text mode
    ESP32_Printf("SMS_SIMPLE:TEXT_MODE\n");
    if (!EC200U_SendCommand_Safe("AT+CMGF=1", "OK", 3000)) {
        ESP32_Printf("ERROR:TEXT_MODE_FAILED\n");
        return 0;
    }

    // Step 3: Send SMS directly
    ESP32_Printf("SMS_SIMPLE:SENDING_HELLO_SMS\n");

    EC200U_ClearRXBuffer();
    snprintf(ec200u_tx_buffer, sizeof(ec200u_tx_buffer), "AT+CMGS=\"%s\"\r", SMS_PHONE_NUMBER);
    HAL_UART_Transmit(&huart2, (uint8_t*)ec200u_tx_buffer, strlen(ec200u_tx_buffer), 1000);

    // Wait for prompt
    uint32_t start_time = HAL_GetTick();
    while (HAL_GetTick() - start_time < 5000) {
        uint8_t received_char;
        if (HAL_UART_Receive(&huart2, &received_char, 1, 10) == HAL_OK) {
            if (ec200u_rx_index < sizeof(ec200u_rx_buffer) - 1) {
                ec200u_rx_buffer[ec200u_rx_index++] = received_char;
                ec200u_rx_buffer[ec200u_rx_index] = '\0';
            }
            if (received_char == '>') {
                ESP32_Printf("SMS_SIMPLE:PROMPT_RECEIVED\n");
                break;
            }
        }
    }

    if (strstr(ec200u_rx_buffer, ">") == NULL) {
        ESP32_Printf("ERROR:NO_SMS_PROMPT\n");
        return 0;
    }

    // Send message
    HAL_Delay(100);
    char* message = "GPS: System ready!";
    snprintf(ec200u_tx_buffer, sizeof(ec200u_tx_buffer), "%s\x1A", message);
    HAL_UART_Transmit(&huart2, (uint8_t*)ec200u_tx_buffer, strlen(ec200u_tx_buffer), 2000);

    // Wait for confirmation
    EC200U_ClearRXBuffer();
    start_time = HAL_GetTick();

    while (HAL_GetTick() - start_time < 10000) {
        uint8_t received_char;
        if (HAL_UART_Receive(&huart2, &received_char, 1, 10) == HAL_OK) {
            if (ec200u_rx_index < sizeof(ec200u_rx_buffer) - 1) {
                ec200u_rx_buffer[ec200u_rx_index++] = received_char;
                ec200u_rx_buffer[ec200u_rx_index] = '\0';
            }
        }

        if (strstr(ec200u_rx_buffer, "+CMGS:") != NULL) {
            ESP32_Printf("SUCCESS:SIMPLE_SMS_SENT\n");
            return 1;
        }

        if (strstr(ec200u_rx_buffer, "ERROR") != NULL) {
            ESP32_Printf("ERROR:SMS_SEND_ERROR:%s\n", ec200u_rx_buffer);
            return 0;
        }
    }

    ESP32_Printf("ERROR:SMS_TIMEOUT\n");
    return 0;
}

void Handle_SMS_Operations(void)
{
    uint32_t current_time = HAL_GetTick();

    // Only send SMS if we have valid GPS data and enough time has passed
    if (gps_data.has_valid_location && (current_time - last_sms_sent >= SMS_INTERVAL_MS)) {
        ESP32_Printf("SMS:PREPARING_HIGH_PRECISION_LOCATION_UPDATE\n");

        // Create high-precision GPS message
        char sms_message[160];
        Create_GPS_SMS_Message_HighPrecision(sms_message, sizeof(sms_message));

        ESP32_Printf("SMS:SENDING_4DECIMAL_MESSAGE:%s\n", sms_message);

        // Try to send SMS
        if (EC200U_SendSMS(SMS_PHONE_NUMBER, sms_message)) {
            ESP32_Printf("SUCCESS:HIGH_PRECISION_SMS_SENT_COUNT_%lu\n", gps_data.sms_sent_count + 1);
            gps_data.sms_sent_count++;

            // Flash LED 5 times for SMS success
            for (int i = 0; i < 5; i++) {
                Status_LED_Set(1);
                HAL_Delay(80);
                Status_LED_Set(0);
                HAL_Delay(80);
            }
        } else {
            ESP32_Printf("WARNING:SMS_SEND_FAILED_GPS_CONTINUES\n");
            gps_data.sms_failed_count++;

            // If too many SMS failures, disable SMS
            if (gps_data.sms_failed_count >= 3) {
                ESP32_Printf("WARNING:TOO_MANY_SMS_FAILURES_DISABLING_SMS\n");
                gps_data.sms_enabled = 0;
                gps_data.sms_ready = 0;
            }
        }

        last_sms_sent = current_time;  // Update timer regardless of success
    }
}

/**
  * @brief  Initialize SMS functionality
  */
uint8_t EC200U_InitializeSMS(void)
{
    ESP32_Printf("=== SMS_INITIALIZATION_DEBUG ===\n");

    // Basic AT test first
    ESP32_Printf("SMS_DEBUG:BASIC_AT_TEST\n");
    if (!EC200U_SendCommand_Safe("AT", "OK", 2000)) {
        ESP32_Printf("ERROR:BASIC_AT_FAILED_FOR_SMS\n");
        return 0;
    }

    // Check SIM status first
    ESP32_Printf("SMS_DEBUG:CHECKING_SIM_STATUS\n");
    if (EC200U_SendCommand_Safe("AT+CPIN?", "OK", 5000)) {
        ESP32_Printf("SMS_DEBUG:SIM_RESPONSE:%s\n", ec200u_rx_buffer);
        if (!strstr(ec200u_rx_buffer, "READY")) {
            ESP32_Printf("ERROR:SIM_NOT_READY\n");
            return 0;
        }
    } else {
        ESP32_Printf("ERROR:SIM_STATUS_CHECK_FAILED\n");
        return 0;
    }

    // Check signal strength
    ESP32_Printf("SMS_DEBUG:CHECKING_SIGNAL_STRENGTH\n");
    if (EC200U_SendCommand_Safe("AT+CSQ", "OK", 3000)) {
        ESP32_Printf("SMS_DEBUG:SIGNAL_RESPONSE:%s\n", ec200u_rx_buffer);
    }

    // Check network registration with detailed response
    ESP32_Printf("SMS_DEBUG:CHECKING_NETWORK_REGISTRATION\n");
    if (!EC200U_SendCommand_Safe("AT+CREG?", "+CREG:", 3000)) {
        ESP32_Printf("ERROR:NETWORK_CHECK_COMMAND_FAILED\n");
        return 0;
    }

    ESP32_Printf("SMS_DEBUG:NETWORK_REG_FULL_RESPONSE:%s\n", ec200u_rx_buffer);

    if (!strstr(ec200u_rx_buffer, ",1") && !strstr(ec200u_rx_buffer, ",5")) {
        ESP32_Printf("ERROR:NETWORK_NOT_REGISTERED_FOR_SMS\n");
        return 0;
    }

    ESP32_Printf("SUCCESS:NETWORK_REGISTERED_FOR_SMS\n");

    // Set SMS text mode
    ESP32_Printf("SMS_DEBUG:SETTING_SMS_TEXT_MODE\n");
    if (!EC200U_SendCommand_Safe("AT+CMGF=1", "OK", 3000)) {
        ESP32_Printf("ERROR:SMS_TEXT_MODE_FAILED\n");
        return 0;
    }

    // Test SMS service
    ESP32_Printf("SMS_DEBUG:TESTING_SMS_SERVICE\n");
    if (!EC200U_SendCommand_Safe("AT+CSMS=1", "OK", 3000)) {
        ESP32_Printf("WARNING:SMS_SERVICE_TEST_FAILED_BUT_CONTINUING\n");
    }

    ESP32_Printf("SUCCESS:SMS_INITIALIZATION_COMPLETED\n");
    return 1;
}

/**
  * @brief  Send SMS message
  */
uint8_t EC200U_SendSMS(const char* phone_number, const char* message)
{
    char cmd_buffer[64];

    ESP32_Printf("=== SMS_SEND_START ===\n");
    ESP32_Printf("SMS:SENDING_TO_%s\n", phone_number);
    ESP32_Printf("SMS:MESSAGE_LENGTH_%d\n", strlen(message));
    ESP32_Printf("SMS:MESSAGE_CONTENT:%s\n", message);

    // Step 1: Check network before sending
    if (!EC200U_SendCommand_Safe("AT+CREG?", "OK", 3000)) {
        ESP32_Printf("ERROR:NETWORK_CHECK_FAILED_BEFORE_SMS\n");
        return 0;
    }

    // Step 2: Send SMS command
    snprintf(cmd_buffer, sizeof(cmd_buffer), "AT+CMGS=\"%s\"", phone_number);

    EC200U_ClearRXBuffer();
    snprintf(ec200u_tx_buffer, sizeof(ec200u_tx_buffer), "%s\r", cmd_buffer);
    HAL_UART_Transmit(&huart2, (uint8_t*)ec200u_tx_buffer, strlen(ec200u_tx_buffer), 1000);

    ESP32_Printf("SMS_DEBUG:WAITING_FOR_PROMPT\n");

    // Wait for ">" prompt
    uint32_t start_time = HAL_GetTick();
    while (HAL_GetTick() - start_time < 5000) {
        uint8_t received_char;
        if (HAL_UART_Receive(&huart2, &received_char, 1, 10) == HAL_OK) {
            if (ec200u_rx_index < sizeof(ec200u_rx_buffer) - 1) {
                ec200u_rx_buffer[ec200u_rx_index++] = received_char;
                ec200u_rx_buffer[ec200u_rx_index] = '\0';
            }

            if (received_char == '>') {
                break;
            }
        }
    }

    ESP32_Printf("SMS_DEBUG:PROMPT_RESPONSE:%s\n", ec200u_rx_buffer);

    if (strstr(ec200u_rx_buffer, ">") == NULL) {
        ESP32_Printf("ERROR:SMS_PROMPT_NOT_RECEIVED\n");
        return 0;
    }

    ESP32_Printf("SUCCESS:SMS_PROMPT_RECEIVED\n");

    // Step 3: Send message content
    ESP32_Printf("SMS_DEBUG:SENDING_MESSAGE_CONTENT\n");
    HAL_Delay(100);
    snprintf(ec200u_tx_buffer, sizeof(ec200u_tx_buffer), "%s\x1A", message);
    HAL_UART_Transmit(&huart2, (uint8_t*)ec200u_tx_buffer, strlen(ec200u_tx_buffer), 2000);

    // Step 4: Wait for confirmation
    ESP32_Printf("SMS_DEBUG:WAITING_FOR_CONFIRMATION\n");
    EC200U_ClearRXBuffer();
    start_time = HAL_GetTick();

    while (HAL_GetTick() - start_time < 15000) {  // 15 second timeout
        uint8_t received_char;
        if (HAL_UART_Receive(&huart2, &received_char, 1, 10) == HAL_OK) {
            if (ec200u_rx_index < sizeof(ec200u_rx_buffer) - 1) {
                ec200u_rx_buffer[ec200u_rx_index++] = received_char;
                ec200u_rx_buffer[ec200u_rx_index] = '\0';
            }
        }

        if (strstr(ec200u_rx_buffer, "+CMGS:") != NULL && strstr(ec200u_rx_buffer, "OK") != NULL) {
            ESP32_Printf("SUCCESS:SMS_SENT_CONFIRMED_RESPONSE:%s\n", ec200u_rx_buffer);
            return 1;
        }

        if (strstr(ec200u_rx_buffer, "ERROR") != NULL || strstr(ec200u_rx_buffer, "+CMS ERROR") != NULL) {
            ESP32_Printf("ERROR:SMS_SEND_ERROR_RESPONSE:%s\n", ec200u_rx_buffer);
            return 0;
        }
    }

    ESP32_Printf("ERROR:SMS_SEND_TIMEOUT_FINAL_RESPONSE:%s\n", ec200u_rx_buffer);
    return 0;
}

/**
  * @brief  Clear EC200U RX buffer safely
  */
void EC200U_ClearRXBuffer(void)
{
    memset(ec200u_rx_buffer, 0, sizeof(ec200u_rx_buffer));
    ec200u_rx_index = 0;
}

/**
  * @brief  Send AT command with strict timeout and error handling
  */
uint8_t EC200U_SendCommand_Safe(const char* command, const char* expected_response, uint32_t timeout)
{
    ESP32_Printf("DEBUG:SENDING_SAFE_CMD:%s\n", command);

    // Clear buffer
    EC200U_ClearRXBuffer();

    // Send command
    snprintf(ec200u_tx_buffer, sizeof(ec200u_tx_buffer), "%s\r\n", command);
    HAL_StatusTypeDef tx_status = HAL_UART_Transmit(&huart2, (uint8_t*)ec200u_tx_buffer,
                                                    strlen(ec200u_tx_buffer), 2000);

    if (tx_status != HAL_OK) {
        ESP32_Printf("ERROR:UART2_TX_FAILED_STATUS_%d\n", tx_status);
        gps_data.communication_errors++;
        return 0;
    }

    // Receive response with strict timeout
    uint32_t start_time = HAL_GetTick();
    uint32_t last_data_time = start_time;

    while (HAL_GetTick() - start_time < timeout) {
        uint8_t received_char;
        HAL_StatusTypeDef rx_status = HAL_UART_Receive(&huart2, &received_char, 1, 10);

        if (rx_status == HAL_OK) {
            last_data_time = HAL_GetTick();

            if (ec200u_rx_index < sizeof(ec200u_rx_buffer) - 1) {
                ec200u_rx_buffer[ec200u_rx_index++] = received_char;
                ec200u_rx_buffer[ec200u_rx_index] = '\0';
            }
        }

        // Stop if no data for 300ms
        if (ec200u_rx_index > 0 && (HAL_GetTick() - last_data_time > 300)) {
            break;
        }

        // Check for expected response
        if (strstr(ec200u_rx_buffer, expected_response) != NULL) {
            ESP32_Printf("SUCCESS:CMD_OK:%s\n", command);
            return 1;
        }

        // Check for errors
        if (strstr(ec200u_rx_buffer, "ERROR") != NULL) {
            ESP32_Printf("ERROR:CMD_ERROR:%s,RESPONSE:%s\n", command, ec200u_rx_buffer);
            gps_data.communication_errors++;
            return 0;
        }
    }

    ESP32_Printf("TIMEOUT:CMD_TIMEOUT:%s\n", command);
    gps_data.communication_errors++;
    return 0;
}

/**
  * @brief  Basic EC200U communication test
  */
uint8_t EC200U_BasicTest(void)
{
    ESP32_Printf("DEBUG:STARTING_BASIC_EC200U_TEST\n");

    // Power cycle EC200U
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
    HAL_Delay(1000);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
    HAL_Delay(3000);  // Wait for boot

    // Try simple AT command
    for (int i = 0; i < 5; i++) {
        ESP32_Printf("DEBUG:AT_TEST_ATTEMPT_%d\n", i + 1);

        if (EC200U_SendCommand_Safe("AT", "OK", 2000)) {
            ESP32_Printf("SUCCESS:BASIC_AT_COMMUNICATION_OK\n");
            return 1;
        }
        HAL_Delay(1000);
    }

    ESP32_Printf("ERROR:BASIC_AT_TEST_FAILED_ALL_ATTEMPTS\n");
    return 0;
}

/**
  * @brief  Progressive EC200U initialization
  */
uint8_t EC200U_Initialize_Progressive(void)
{
    ESP32_Printf("DEBUG:PROGRESSIVE_EC200U_INITIALIZATION\n");

    // Basic configuration commands
    if (!EC200U_SendCommand_Safe("ATE0", "OK", 2000)) {
        ESP32_Printf("WARNING:ECHO_DISABLE_FAILED\n");
    }

    if (!EC200U_SendCommand_Safe("AT+CMEE=1", "OK", 2000)) {
        ESP32_Printf("WARNING:ERROR_REPORTING_SETUP_FAILED\n");
    }

    // Check module info
    if (EC200U_SendCommand_Safe("AT+GMI", "OK", 3000)) {
        ESP32_Printf("INFO:MODULE_MANUFACTURER_OK\n");
    }

    ESP32_Printf("SUCCESS:BASIC_MODULE_CONFIGURATION_COMPLETE\n");
    return 1;  // Always succeed for progressive approach
}

/**
  * @brief  Safe GNSS startup
  */
uint8_t EC200U_StartGNSS_Safe(void)
{
    ESP32_Printf("DEBUG:STARTING_GNSS_SAFELY\n");

    // Stop any existing GNSS session first
    EC200U_SendCommand_Safe("AT+QGPSEND", "OK", 3000);
    HAL_Delay(1000);

    // Configure GNSS
    EC200U_SendCommand_Safe("AT+QGPSCFG=\"outport\",\"usernmea\"", "OK", 3000);
    EC200U_SendCommand_Safe("AT+QGPSCFG=\"nmeasrc\",1", "OK", 3000);

    // Start GNSS
    if (EC200U_SendCommand_Safe("AT+QGPS=1", "OK", 5000)) {
        ESP32_Printf("SUCCESS:GNSS_START_COMMAND_ACCEPTED\n");
        return 1;
    }

    ESP32_Printf("ERROR:GNSS_START_COMMAND_FAILED\n");
    return 0;
}

/**
  * @brief  Enhanced GPS location retrieval with better parsing
  */
uint8_t EC200U_GetLocation_Safe(void)
{
    gps_data.gps_attempts++;

    if (EC200U_SendCommand_Safe("AT+QGPSLOC?", "OK", 5000)) {
        // Look for GPS data in response
        if (strstr(ec200u_rx_buffer, "+QGPSLOC:") != NULL) {
            char* data_start = strstr(ec200u_rx_buffer, "+QGPSLOC: ");
            if (data_start) {
                data_start += 10;  // Skip "+QGPSLOC: "

                // Check if we have data (not empty)
                if (strlen(data_start) > 10) {
                    ESP32_Printf("GPS_RAW:%s\n", data_start);

                    // Parse GPS fields: time,lat,lon,hdop,alt,fix,cog,spkm,spkn,date,nsat
                    char temp_time[20] = {0};
                    char temp_lat[20] = {0};
                    char temp_lon[20] = {0};
                    char temp_hdop[10] = {0};
                    char temp_alt[16] = {0};
                    char temp_fix[5] = {0};
                    char temp_cog[10] = {0};
                    char temp_spkm[10] = {0};
                    char temp_spkn[10] = {0};
                    char temp_date[20] = {0};
                    char temp_sats[8] = {0};

                    // Use sscanf to parse all fields properly
                    int parsed_fields = sscanf(data_start,
                        "%19[^,],%19[^,],%19[^,],%9[^,],%15[^,],%4[^,],%9[^,],%9[^,],%9[^,],%19[^,],%7s",
                        temp_time, temp_lat, temp_lon, temp_hdop, temp_alt,
                        temp_fix, temp_cog, temp_spkm, temp_spkn, temp_date, temp_sats);

                    ESP32_Printf("DEBUG:PARSED_%d_FIELDS_FROM_GPS\n", parsed_fields);

                    if (parsed_fields >= 11) {
                        // Copy parsed data to GPS structure
                        strncpy(gps_data.timestamp, temp_time, sizeof(gps_data.timestamp) - 1);
                        strncpy(gps_data.latitude, temp_lat, sizeof(gps_data.latitude) - 1);
                        strncpy(gps_data.longitude, temp_lon, sizeof(gps_data.longitude) - 1);
                        strncpy(gps_data.altitude, temp_alt, sizeof(gps_data.altitude) - 1);
                        strncpy(gps_data.satellites, temp_sats, sizeof(gps_data.satellites) - 1);
                        gps_data.fix_type = atoi(temp_fix);

                        ESP32_Printf("DEBUG:GPS_FIELDS_LAT=%s,LON=%s,ALT=%s,FIX=%d,SATS=%s\n",
                                     gps_data.latitude, gps_data.longitude, gps_data.altitude,
                                     gps_data.fix_type, gps_data.satellites);

                        // Convert NMEA coordinates to decimal degrees
                        gps_data.decimal_lat = ConvertNMEAToDecimal(gps_data.latitude);
                        gps_data.decimal_lon = ConvertNMEAToDecimal(gps_data.longitude);

                        // Validate coordinates
                        if (gps_data.decimal_lat != 0.0 && gps_data.decimal_lon != 0.0 &&
                            gps_data.decimal_lat >= -90.0 && gps_data.decimal_lat <= 90.0 &&
                            gps_data.decimal_lon >= -180.0 && gps_data.decimal_lon <= 180.0) {

                            gps_data.has_valid_location = 1;
                            gps_data.last_update = HAL_GetTick();

                            ESP32_Printf("SUCCESS:GPS_COORDINATES_AVAILABLE\n");

                            return 1;
                        } else {
                            ESP32_Printf("ERROR:INVALID_GPS_COORDINATES\n");
                        }
                    } else {
                        ESP32_Printf("ERROR:INSUFFICIENT_GPS_FIELDS_PARSED_%d\n", parsed_fields);
                    }
                } else {
                    ESP32_Printf("DEBUG:EMPTY_GPS_RESPONSE_NO_FIX\n");
                }
            }
        }

        // Check for specific GPS errors
        if (strstr(ec200u_rx_buffer, "516") != NULL) {
            ESP32_Printf("INFO:GPS_SEARCHING_SATELLITES_ERROR_516\n");
        }
    }

    return 0;
}

/**
  * @brief  Convert NMEA coordinate to decimal degrees (enhanced precision)
  */
float ConvertNMEAToDecimal(const char* nmea_coord)
{
    if (strlen(nmea_coord) < 5) return 0.0;

    // Make a copy to work with
    char coord_copy[20];
    strncpy(coord_copy, nmea_coord, sizeof(coord_copy) - 1);
    coord_copy[sizeof(coord_copy) - 1] = '\0';

    // Extract direction (last character)
    char direction = coord_copy[strlen(coord_copy) - 1];
    coord_copy[strlen(coord_copy) - 1] = '\0';  // Remove direction

    // Convert to float
    float coord_value = atof(coord_copy);

    // Extract degrees and minutes
    float degrees, minutes;

    if (strlen(coord_copy) <= 9) {
        // Latitude format: DDMM.MMMMM (like 1300.1355)
        degrees = (int)(coord_value / 100);  // Get DD part (13)
        minutes = coord_value - (degrees * 100);  // Get MM.MMMMM part (00.1355)
    } else {
        // Longitude format: DDDMM.MMMMM (like 07729.7901)
        degrees = (int)(coord_value / 100);  // Get DDD part (77)
        minutes = coord_value - (degrees * 100);  // Get MM.MMMMM part (29.7901)
    }

    // Convert to decimal degrees
    float decimal = degrees + (minutes / 60.0);

    // Apply direction
    if (direction == 'S' || direction == 'W') {
        decimal = -decimal;
    }

    ESP32_Printf("DEBUG:NMEA_CONVERT_%s->%.6f\n", nmea_coord, decimal);

    return decimal;
}

/**
  * @brief  Handle EC200U errors gracefully
  */
void Handle_EC200U_Error(const char* error_msg)
{
    ESP32_Printf("ERROR:EC200U_%s\n", error_msg);
    gps_data.communication_errors++;

    // Reset module state on critical errors
    if (gps_data.communication_errors > 10) {
        ESP32_Printf("WARNING:TOO_MANY_ERRORS_RESETTING_MODULE_STATE\n");
        gps_data.module_ready = 0;
        gps_data.gnss_started = 0;
        gps_data.has_valid_location = 0;
        gps_data.communication_errors = 0;
        initialization_step = 0;  // Restart initialization
        current_init_attempt = 0;
    }
}

/**
  * @brief  Send formatted message to ESP32
  */
void ESP32_Printf(const char* format, ...)
{
    va_list args;
    va_start(args, format);
    vsnprintf(esp32_tx_buffer, sizeof(esp32_tx_buffer), format, args);
    va_end(args);

    HAL_UART_Transmit(&huart1, (uint8_t*)esp32_tx_buffer, strlen(esp32_tx_buffer), 3000);
    HAL_Delay(2);
}

/**
  * @brief  Toggle status LED
  */
void Status_LED_Toggle(void)
{
    HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_0);
}

/**
  * @brief  Set status LED state
  */
void Status_LED_Set(uint8_t state)
{
    if (state) {
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_SET);
    } else {
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_RESET);
    }
}

/* USER CODE END 4 */

// System configuration functions (same as before)
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 40;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

static void MX_USART1_UART_Init(void)
{
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
}

static void MX_USART2_UART_Init(void)
{
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
}

static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOA_CLK_ENABLE();

  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0|GPIO_PIN_5, GPIO_PIN_RESET);

  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_SET);
    for(volatile int i = 0; i < 100000; i++);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_RESET);
    for(volatile int i = 0; i < 100000; i++);
  }
}
